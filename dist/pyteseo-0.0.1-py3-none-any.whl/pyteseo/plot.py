def plot_grid(df):
    print("doing something...")


def plot_coastline(df):
    print("doing something...")


def plot_currents(df):
    print("doing something...")


def plot_winds(df):
    print("doing something...")


def plot_waves(df):
    print("doing something...")


def plot_particles(df):
    print("doing something...")


def plot_properties(df):
    print("doing something...")


def plot_grids(ds):
    print("doing something...")
