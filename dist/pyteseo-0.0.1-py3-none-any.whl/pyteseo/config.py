""" Logic needed to define variables needed to write cfg and run files 
"""

# TODO - THINK, DEFINE MODULE AND ADD TASKS TO THE BACKLOG!!!


def floater_release():
    pass


def oil_release():
    pass


def hns_release():
    pass


def forcings():
    pass


def domain():
    pass


def environment():
    pass


def calibration_coef():
    pass


def simulation_type():
    pass
