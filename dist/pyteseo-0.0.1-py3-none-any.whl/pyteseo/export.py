from pyteseo.io import read_particles, read_properties, read_grids


def particles_to_csv():
    # read_particles()
    print("doing something...")


def particles_to_json():
    # read_particles()
    print("doing something...")


def particles_to_geojson():
    # read_particles()
    print("doing something...")


def properties_to_csv():
    # read_propierties()
    print("doing something...")


def properties_to_json():
    # read_propierties()
    print("doing something...")


def grids_to_xarray():
    # read_grids()
    print("doing something...")


def grids_to_netcdf():
    # read_grids()
    print("doing something...")


def grids_to_csv():
    # read_grids()
    print("doing something...")


def grids_to_json():
    # read_grids()
    print("doing something...")
